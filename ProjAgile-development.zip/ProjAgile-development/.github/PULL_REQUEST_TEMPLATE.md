## Developer: 
- [ ] PR voldoet aan de acceptatiecriteria
- [ ] Er is een happy flow Dusk test toegevoegd
- [ ] Er is een sad flow Dusk test toegevoegd
- [ ] Dusk test is uitgevoerd en geslaagd
- [ ] PR is getest op toegankelijkheid (screenreader)
- [ ] Tekstuele content is in een resource file geplaatst
- [ ] PR is onafhankelijk van andere PR's

### Reviewer 1:
- [ ] PR voldoet aan de acceptatiecriteria
- [ ] PR is getest op toegankelijkheid (screenreader)
- [ ] Dusk test is uitgevoerd en geslaagd
- [ ] Tekstuele content is in een resource file geplaatst
- [ ] PR is onafhankelijk van andere PR's

### Reviewer 2:
- [ ] PR voldoet aan de acceptatiecriteria
- [ ] PR is getest op toegankelijkheid (screenreader)
- [ ] Dusk test is uitgevoerd en geslaagd
- [ ] Tekstuele content is in een resource file geplaatst
- [ ] PR is onafhankelijk van andere PR's



## Functie
<!-- Wat doet het? -->

<!-- Voeg hier optioneel ook afbeeldingen toe -->

## User Story
<!-- Voeg hier een link to naar Jira -->

## Belangrijke Opmerkingen
<!-- Waar kan deze code een effect op hebben, waar moet extra naar gekeken worden door de reviewers? -->
