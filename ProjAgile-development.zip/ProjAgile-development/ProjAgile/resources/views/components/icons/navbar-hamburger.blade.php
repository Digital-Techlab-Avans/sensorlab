<svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="25" height="25">
    <path d="m54,14H10c-1.1,0-2,.9-2,2s.9,2,2,2h44c1.1,0,2-.9,2-2s-.9-2-2-2Z"/>
    <path d="m38,30H10c-1.1,0-2,.9-2,2s.9,2,2,2h28c1.1,0,2-.9,2-2s-.9-2-2-2Z"/>
    <path d="m24,46h-14c-1.1,0-2,.9-2,2s.9,2,2,2h14c1.1,0,2-.9,2-2s-.9-2-2-2Z"/>
  </svg>