<?php
    require_once 'shared.php';

    return [
        //Login
        'developed_by' => 'Product ontwikkeld in samenwerking tussen Communicatie & Multimedia Design en Informatica van Avans ’s-Hertogenbosch',
        'questions_about_sensorlab' => 'Vragen over het SensorLab? Neem dan contact op met Pleun Wilting (ppj.wilting@avans.nl)',
    ];
