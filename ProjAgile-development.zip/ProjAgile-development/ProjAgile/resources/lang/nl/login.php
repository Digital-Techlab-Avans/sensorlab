<?php
    require_once 'shared.php';

    return [
        'login_header' => 'Welkom bij',
        'login_button' => 'Log In',
        'email' => EMAIL,
        'email_placeholder' => 'Avans e-mail',
        'password' => 'Wachtwoord',
    ];
